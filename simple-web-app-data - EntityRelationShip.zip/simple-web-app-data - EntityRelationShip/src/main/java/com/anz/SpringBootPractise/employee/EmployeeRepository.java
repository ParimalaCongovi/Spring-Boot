package com.anz.SpringBootPractise.employee;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


public interface EmployeeRepository extends CrudRepository<Employee,String> {
	public List<Employee> findByDepartmentId(String deptId);

}
