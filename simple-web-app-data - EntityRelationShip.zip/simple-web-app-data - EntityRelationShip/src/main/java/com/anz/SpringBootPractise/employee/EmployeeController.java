package com.anz.SpringBootPractise.employee;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anz.SpringBootPractise.department.Department;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping("/departments/{id}/employees")
	public List<Employee> listOfEmployees(@PathVariable String id)
	{
		return employeeService.getAllEmployees(id); 
	}
	
	@RequestMapping("/departments/{deptId}/employees/{employeeId}")
	public Optional<Employee> getEmployee(@PathVariable String employeeId)
	{
		return employeeService.getEmployee(employeeId);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/departments/{deptId}/employees")
	public void addEmployee(@RequestBody Employee employee,@PathVariable String deptId)
	{
		employee.setDepartment(new Department(deptId,""));
		employeeService.addEmployee(employee);
	}
	@RequestMapping(method=RequestMethod.PUT, value="/departments/{deptId}/employees/{id}")
	public void updateEmployee(@RequestBody Employee employee, @PathVariable String deptId,@PathVariable String id)
	{
		employee.setDepartment(new Department(deptId,""));
		employeeService.updateEmployee(employee);
	}
	@RequestMapping(method=RequestMethod.DELETE, value="/departments/{deptId}/employees/{id}")
	public void deleteEmployee( @PathVariable String id)
	{
		employeeService.deleteEmployee(id);
	}

}
