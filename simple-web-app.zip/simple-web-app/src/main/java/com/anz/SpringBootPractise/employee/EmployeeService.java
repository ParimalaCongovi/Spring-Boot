package com.anz.SpringBootPractise.employee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	
	private List<Employee> employees = new ArrayList<>(Arrays.asList( new Employee("Parimala","Congovi",22),
			new Employee("Kavya","Congovi",20),
			new Employee("Suresh","Congovi",50)
			));
	
	public List<Employee> getAllemployees(){
		return employees;
	}
	
	public Employee getEmployee(String firstName)
	{
		return employees.stream().filter(e -> e.getFirstName().equals(firstName)).findFirst().get();
	}
	
	public void addEmployee(Employee emp)
	{
		employees.add(emp);
	}

	public void updateEmployee(String name, Employee employee) {
		Employee emp=employees.stream().filter(e -> e.getFirstName().equals(name)).findFirst().get();
		employees.set(employees.indexOf(emp), employee);
	}

	public void deleteEmployee(String name) {
		employees.removeIf(e -> e.getFirstName().equals(name));
		
	}

}
